from fbs_runtime.application_context.${python_bindings} import ApplicationContext
from ${python_bindings}.QtWidgets import QMainWindow

import sys

if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    window = QMainWindow()
    window.resize(250, 150)
    window.show()
    exit_code = appctxt.app.${exec_method}()      # 2. Invoke appctxt.app.${exec_method}()
    sys.exit(exit_code)