![Sample app icon](linux/128.png)

This directory contains the icons that are displayed for your app. Feel free to
change them by placing your own copies into `src/main/icons` in your project
directory.

The difference between the icons on Mac and the other platforms is that on Mac,
they contain a ~5% transparent margin. This is because otherwise they look too
big (eg. in the Dock or in the app switcher).

Icon.ico is used on Windows and Linux. You can create it from the .png files
with [an online tool](http://icoconvert.com/Multi_Image_to_one_icon/).
