from fbs_runtime import _source, _frozen
from fbs_runtime._error import FbsError
from fbs_runtime._settings import LazySettings
from fbs_runtime.application_context import is_frozen

"""
This dictionary contains the values of the settings listed in setting
"public_settings". Eg. `PUBLIC_SETTINGS['version']`.
"""
PUBLIC_SETTINGS = \
    LazySettings((_frozen if is_frozen() else _source).load_public_settings)